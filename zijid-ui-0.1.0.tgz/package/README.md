# Zijid UI - 基于 Vue 3 的 Windows 10 风格组件库

## 📖 简介

Zijid UI 是一个基于 Vue 3 和 TypeScript 的 Windows 10 风格组件库，提供了一套完整的桌面应用 UI 组件。

## ✨ 特性

- 🎨 **Windows 10 风格**：经典原生的桌面界面设计
- ⚡ **Vue 3 + TypeScript**：完整的类型支持，优秀的开发体验
- 📦 **按需引入**：支持 Tree-shaking，减少包体积
- 🔧 **30+ 精美组件**：涵盖按钮、弹窗、图标、面板等常用组件
- 🎯 **响应式设计**：支持桌面和移动端

## 🚀 快速开始

### 安装

```bash
npm install zijid-ui
```

### 基础使用

```vue
<template>
  <div>
    <ZButton type="primary" @click="showWindow = true">打开窗口</ZButton>
    <ZWindow 
      v-model="showWindow" 
      title="我的窗口" 
      :x="100" 
      :y="100"
      :width="400" 
      :height="300"
    >
      <p>欢迎使用 ZWindow 组件！</p>
    </ZWindow>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ZButton, ZWindow } from 'zijid-ui'

const showWindow = ref(false)
</script>
```

## 📁 项目结构

```
zijid-ui/
├── src/                    # 源代码
│   ├── components/         # 组件源码
│   │   ├── button/         # 按钮组件
│   │   ├── window/         # 窗口组件
│   │   ├── input/          # 输入框组件
│   │   └── ...            # 其他组件
│   ├── composables/        # 组合式函数
│   ├── styles/            # 样式文件
│   └── index.ts           # 入口文件
├── demo/                  # 演示项目
│   ├── main-demo.html     # 主演示页面
│   ├── complete-api-docs.html  # 完整API文档
│   └── working-demo.html  # 工作演示页面
├── dist/                  # 构建产物
├── package.json           # 项目配置
└── README.md              # 项目说明
```

## 🎨 组件列表

### 基础组件
- **ZButton** - 按钮组件
- **ZInput** - 输入框组件
- **ZSelect** - 选择器组件
- **ZCheckbox** - 复选框组件
- **ZRadio** - 单选框组件
- **ZSwitch** - 开关组件

### 布局组件
- **ZWindow** - 窗口组件
- **ZPanel** - 面板组件
- **ZSplitter** - 分割器组件
- **ZScrollArea** - 滚动区域组件

### 导航组件
- **ZMenu** - 菜单组件
- **ZDropdown** - 下拉菜单组件
- **ZTabs** - 选项卡组件
- **ZToolbar** - 工具栏组件
- **ZStatusBar** - 状态栏组件

### 反馈组件
- **ZDialog** - 对话框组件
- **ZToast** - 消息提示组件
- **ZTooltip** - 提示组件
- **ZContextMenu** - 右键菜单组件

### 数据组件
- **ZList** - 列表组件
- **ZTree** - 树形组件
- **ZTable** - 表格组件
- **ZSearchBox** - 搜索框组件
- **ZProgress** - 进度条组件
- **ZSlider** - 滑块组件

### 其他组件
- **ZIcon** - 图标组件
- **ZDesktop** - 桌面组件
- **ZTaskbar** - 任务栏组件
- **ZStartMenu** - 开始菜单组件

## 📖 演示和文档

### 演示页面

1. **主演示页面** - 包含所有组件的演示
   ```
   demo/main-demo.html
   ```

2. **完整API文档** - 详细的API文档
   ```
   demo/complete-api-docs.html
   ```

3. **工作演示页面** - 简化的演示页面
   ```
   demo/working-demo.html
   ```

### 使用演示页面

由于 Vite 开发服务器权限问题，我们使用静态 HTML 页面进行演示：

```bash
# 打开主演示页面
open demo/main-demo.html

# 打开完整API文档
open demo/complete-api-docs.html
```

## 🔧 构建和开发

### 构建组件库

```bash
# 使用构建脚本
./build.sh          # Linux/Mac
build.bat           # Windows

# 或者手动构建
npm install          # 安装依赖
npm run build        # 构建组件库
```

### 开发模式

```bash
# 进入 demo 目录
cd demo

# 使用静态演示页面
open main-demo.html

# 或者尝试启动开发服务器（需要管理员权限）
npm run dev
```

## 📋 API 文档

### ZWindow 组件

#### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| modelValue | boolean | undefined | 窗口是否显示 |
| title | string | "Window" | 窗口标题 |
| x | number | 0 | 窗口 X 坐标位置 |
| y | number | 0 | 窗口 Y 坐标位置 |
| width | number \| string | 400 | 窗口宽度 |
| height | number \| string | 300 | 窗口高度 |
| minimized | boolean | undefined | 窗口是否最小化 |
| maximized | boolean | undefined | 窗口是否最大化 |
| draggable | boolean | true | 是否可拖拽 |

#### Events

| 事件名 | 参数 | 说明 |
|--------|------|------|
| update:modelValue | boolean | 窗口显示状态变化时触发 |
| close | - | 窗口关闭时触发 |
| minimize | - | 窗口最小化时触发 |
| maximize | - | 窗口最大化时触发 |
| move | { x: number; y: number } | 窗口移动时触发 |

### ZButton 组件

#### Props

| 属性名 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| type | "primary" \| "secondary" \| "success" \| "danger" \| "warning" \| "ghost" | "secondary" | 按钮类型 |
| size | "small" \| "medium" \| "large" | "medium" | 按钮大小 |
| disabled | boolean | false | 是否禁用 |
| loading | boolean | false | 是否加载中 |

## 🐛 故障排除

### 构建权限问题

如果遇到 `spawn EPERM` 错误，请尝试：

1. **以管理员身份运行终端**
   ```bash
   # 右键点击终端，选择"以管理员身份运行"
   ```

2. **使用 WSL (Windows Subsystem for Linux)**
   ```bash
   # 在 WSL 中运行
   ./build.sh
   ```

3. **使用 Docker**
   ```bash
   # 构建 Docker 镜像
   docker build -t zijid-ui .
   ```

### 依赖问题

如果遇到依赖问题，请清理并重新安装：

```bash
rm -rf node_modules package-lock.json
npm install
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License

## 🔗 相关链接

- [Vue 3 文档](https://vuejs.org/)
- [TypeScript 文档](https://www.typescriptlang.org/)
- [Vite 文档](https://vitejs.dev/)
